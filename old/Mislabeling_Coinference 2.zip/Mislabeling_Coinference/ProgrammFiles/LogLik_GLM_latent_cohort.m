function [LogL,dLogL] = LogLik_GLM_latent_cohort(x,X,Y,N_X,TT,GLM_function,N_cohorts,TT_full)
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here
% the epsilon used for avoiding infinity
myeps = 1e-13;
P=x(1:N_X);%tau=x(2*N_X);
risk=x(2*N_X:2*N_X+N_cohorts-1);
LogL=0;
dLogL=zeros(1,2*N_X-1+N_cohorts);
R=[1-risk(1) risk(2);risk(1) 1-risk(2)];
for n=1:N_cohorts
%      if n==1
%          R=[1 0;0 1]; 
%      else
%          R=[1-risk(1) risk(2);risk(1) 1-risk(2)];
%      end
        [phi1_s,dphi1_s]=feval(GLM_function,P,X{n});

    temp = max((R(1,1)*(1-phi1_s).*(1-Y{n}) + (1-R(1,1))*phi1_s.*(1-Y{n})...
        +(1-R(2,2))*(1-phi1_s).*Y{n}+R(2,2)*phi1_s.*Y{n}),myeps);
    %%temp1 = max(R(1,1)*(1-phi1_s) + (1-R(1,1))*phi1_s);
    %%temp2 = max((1-R(2,2))*(1-phi1_s)+R(2,2)*phi1_s,myeps);
    %%% add increment of function value with respect to this cohort
    %%LogL=LogL + sum(log(temp1).*(1-Y{n}))+sum(log(temp2).*Y{n});

    % add increment of function value with respect to this cohort
    LogL=LogL + sum(log(temp));

    % add increment of gradient with respect to parameters P
    % in general : d{log(f(P))} = (1/f(P))*df(P)
    % in our case: d{log(temp(P))} = (1/temp)*(r1*dphi1*Y1 + r2*dphi2*Y2)
    % dphi2 = d(1-phi1) = -dphi1
    dLogL(1:N_X) = dLogL(1:N_X) + ...
            sum(...
                bsxfun(@times,...
                -R(1,1)*bsxfun(@times,dphi1_s,1-Y{n}')...
                      +(1-R(1,1))*bsxfun(@times,dphi1_s,1-Y{n}') ...
                      - (1-R(2,2))*bsxfun(@times,dphi1_s,Y{n}')...
                      +R(2,2)*bsxfun(@times,dphi1_s,Y{n}')...
                   ,1./temp')...
            ,2)';


%     for t=1:TT{n}
%         [phi,dphi]=feval(GLM_function,P,X{n}(t,:));
%         %Y_mod=1+exp(-P*X(t,:)');%max(P*X(t,:)',1e-12);
%         phi=min(max(phi,1e-13),1-1e-13);
%         phi2=min(max(phi*(Y{n}(t)-risk(n))+(1-phi)*(1-Y{n}(t)+risk(n)),1e-13),1-1e-13);
%         
%         %LogL=LogL+log(phi)*tau+log(1-phi)*(1-tau);
%         LogL=LogL+log(phi2);
%         %dLogL(1:N_X)=dLogL(1:N_X)+tau*(1/phi)*dphi'-(1-tau)*(1/(1-phi))*dphi';
%         %dLogL(2*N_X)=dLogL(2*N_X)+log(phi)-log(1-phi);%Tl(1,t)*(1/phi)*dphi'-Tl(2,t)*(1/(1-phi))*dphi';
%         dLogL(1:N_X)=dLogL(1:N_X)+1./(phi2).*(dphi'*(Y{n}(t)-risk(n))-dphi'*(1-Y{n}(t)+risk(n)));%Tl(1,t)*(1/phi)*dphi'-Tl(2,t)*(1/(1-phi))*dphi';
%         dLogL(2*N_X-1+n)=1./(phi2).*(-phi+(1-phi));%Tl(1,t)*(1/phi)*dphi'-Tl(2,t)*(1/(1-phi))*dphi';
%     end
end

LogL=-(1/(TT_full))*LogL;%+eps1*sum(abs(P(2:N_X)));
dLogL=-(1/(TT_full))*dLogL;%+eps1*[0 ones(1,N_X-1) zeros(1,N_X-1)];
end

