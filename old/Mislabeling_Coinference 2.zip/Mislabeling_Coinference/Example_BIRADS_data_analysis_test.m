clear all 
close all
addpath('Data/');
addpath('ProgrammFiles/');
addpath('Output/');
Data=load('mammographic_masses.data.txt');
ZZ=Data(:,1);
XXX=Data(:,2:size(Data,2)-1);
YY=Data(:,size(Data,2));
for t=1:size(XXX,1)
XX(t,:)=[1 XXX(t,2)==1:4 XXX(t,3)==1:5 XXX(t,4)==1:4 ...
    1-(XXX(t,2)==1:4) 1-(XXX(t,3)==1:5) 1-(XXX(t,4)==1:4) XXX(t,1)./100];
end
label{1}='base risk factor';
label{2}='shape round';label{3}='shape oval';
label{4}='shape lobular';label{5}='shape irregular';
label{6}='margin circumscribed';label{7}='margin microlobulated';
label{8}='margin obscured';label{9}='margin ill-defined';
label{10}='margin spiculated';label{11}='density high';label{12}='density iso';
label{13}='density low';label{14}='density fat-containing';

label{15}='shape not round';label{16}='shape not oval';
label{17}='shape not lobular';label{18}='shape not irregular';
label{19}='margin not circumscribed';label{20}='margin not microlobulated';
label{21}='margin not obscured';label{22}='margin not ill-defined';
label{23}='margin not spiculated';label{24}='density not high';label{25}='density not iso';
label{26}='density not low';label{27}='density not fat-containing';
label{28}='age';

ind_benign=find(YY==0);
ind_malignant=find(YY==1);

X{1}=XX(ind_malignant,:);X{2}=XX(ind_benign,:);
Y{1}=YY(ind_malignant,:);Y{2}=YY(ind_benign,:);
Z{1}=ZZ(ind_malignant,:);Z{2}=ZZ(ind_benign,:);
T{1}=length(ind_malignant);T{2}=length(ind_benign);
risk{2}=0;
risk{1}=[0.006];
randn('seed',1);
rand('seed',1);
risk_cohort_visualise=1;
GLM_function='logit';
C=[8];
ParallelBlockSize=200;

N_cohorts=numel(T);
train_proportion=3/4;
N_bootstrap=50;
%poolobj = parpool(12);
N_X=size(X{1},2);
P=zeros(length(C),2*N_X-1+N_cohorts,length(risk{risk_cohort_visualise}),N_bootstrap);
for n_bootstrap=1:N_bootstrap
    for n=1:N_cohorts
        TT=T{n};
        ind{n}=randperm(TT);
        [mm,ind_back{n}]=sort(ind{n});
        X{n}=X{n}(ind{n},:);Y{n}=Y{n}(ind{n},:);Z{n}=Z{n}(ind{n},:);
        N_train{n}=round(train_proportion*TT);
        X_train{n}=X{n}(1:N_train{n},:);Y_train{n}=Y{n}(1:N_train{n},:);Z_train{n}=Z{n}(1:N_train{n},:);
        X_valid{n}=X{n}((1+N_train{n}):TT,:);Y_valid{n}=Y{n}((1+N_train{n}):TT,:);Z_valid{n}=Z{n}((1+N_train{n}):TT,:);
        TT_valid{n}=size(X_valid{n},1);
    end
    
    
    NST=2;
    MEM=1;
    
    i_s=1;i_ns=1;
    P_init=[];
    ind_init=[];
    clear LogL BIC ind Pl LogLl BICl indl
    tt_ind=1
    for i=1:length(C)
            if n_bootstrap==1
                if tt_ind==1
                    in.xxx_init=[];
                else
                    in.xxx_init=outs{tt_ind-1}.P;
                end
            else
                in.xxx_init=squeeze(P(i,:,1,n_bootstrap-1));
            end
        in.Y=Y_train;
        in.X=X_train;
        in.TT=N_train;
        in.GLM_function=GLM_function;
        in.eps1=C(tt_ind);
        in.risk=risk;
        in.risk{1}=risk{1}(1);
        in.anneal=3;
        in.Y_valid=Y_valid;
        in.X_valid=X_valid;
        in.TT_valid=TT_valid;
        if n_bootstrap==1
            outs{tt_ind} = DiscreteGLM_cohort(in);
            
            LogL(tt_ind)=outs{tt_ind}.LogL;
            LogL_valid(tt_ind)=outs{tt_ind}.LogL_valid;
            AICc(tt_ind)=outs{tt_ind}.AICc;
            BIC(tt_ind)=outs{tt_ind}.BIC;
        end
        tt_ind=tt_ind+1;
    end
    [~,ii]=min(LogL_valid);
    
    
    tt=1;
    Block=1
    clear in
    for ind_dr=1:length(risk{risk_cohort_visualise})
        for n_eps=1:length(C)
                 if n_bootstrap==1
                    in{tt}.xxx_init=outs{n_eps}.P;
                    in{tt}.xxx_init(2*N_X-1+risk_cohort_visualise)=risk{risk_cohort_visualise}(ind_dr);
                else
                    in{tt}.xxx_init=P(n_eps,:,ind_dr,n_bootstrap-1);
                end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            in{tt}.Y=Y_train;
            in{tt}.X=X_train;
            in{tt}.TT=N_train;
            in{tt}.GLM_function=GLM_function;
            in{tt}.eps1=C(n_eps);
            for n=1:N_cohorts
                if n~=risk_cohort_visualise
                    in{tt}.risk{n}=risk{n}(1);
                else
                    in{tt}.risk{n}=risk{n}(ind_dr);
                end
            end
            in{tt}.anneal=3;
            in{tt}.Y_valid=Y_valid;
            in{tt}.X_valid=X_valid;
            in{tt}.TT_valid=TT_valid;
            in{tt}.i=ind_dr;in{tt}.j=n_eps;
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if and(tt<ParallelBlockSize,(Block-1)*ParallelBlockSize+tt<length(risk{risk_cohort_visualise})*length(C))
                tt=tt+1;
            else
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                if Block==1
                    kkk=0;
                else
                    kkk=numel(out);
                end
                for ind_par=1:numel(in)
                    out{kkk+ind_par} = DiscreteGLM_cohort(in{ind_par});
                    out{kkk+ind_par}.i=in{ind_par}.i;
                    out{kkk+ind_par}.j=in{ind_par}.j;
                    out{kkk+ind_par}.index=kkk+ind_par;
                end
                 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                tt=1;
                clear in
                Block=Block+1
            end
        end
    end
    
    
    
    for ttt=1:numel(out)
        for ind_p=1:length(out{ttt}.P)
            P(out{ttt}.j,ind_p,out{ttt}.i,n_bootstrap)=out{ttt}.P(ind_p);
        end
        BICs(out{ttt}.j,out{ttt}.i,n_bootstrap)=out{ttt}.BIC;
        AICcs(out{ttt}.j,out{ttt}.i,n_bootstrap)=out{ttt}.AICc;
        LogLs(out{ttt}.j,out{ttt}.i,n_bootstrap)=out{ttt}.LogL;
        LogLs_valid(out{ttt}.j,out{ttt}.i,n_bootstrap)=out{ttt}.LogL_valid;
        t(ttt)=out{ttt}.index;
    end
    save Output/birads_intermediate
    clear out
end
clear P_opt P_opt0 LogL_range
P_model=mean(squeeze(P(1,:,1,:))');
r_test=[0.0:0.002:0.12];N_ens=500;
r_range=[0:0.0005:0.2];
for ind_r=1:length(r_test)
    in{ind_r}.PP=P_model;in{ind_r}.PP(2*N_X)=r_test(ind_r);
    in{ind_r}.r_range=r_range;
    in{ind_r}.N_ens=N_ens;in{ind_r}.GLM='logit';
    in{ind_r}.X=X;
end
parfor ir=1:length(r_test)
   [out{ir}] = GenerateTrajectoryGLM_with_Mislabeling_parallel(in{ir});  
end
for ir=1:length(r_test)
r_opt=[];
    for t=1:N_ens
        [~,ii]=min(out{ir}.LogL_range(t,:));
        r_opt=[r_opt r_range(ii)];
    end
    mean_r(ir)=mean(r_opt);
    quantile_min(ir)=quantile(r_opt,0.025);
    quantile_max(ir)=quantile(r_opt,0.975);
end
figure;plot(r_test,mean_r,'LineWidth',2);hold on;fill([r_test r_test(length(r_test):-1:1)],[quantile_max quantile_min(length(r_test):-1:1)],'b','LineWidth',2);
plot(r_test,r_test,'r--','LineWidth',3)
set(gca,'FontSize',24,'LineWidth',2);
xlabel('r_{model}, true mislabeling rate (benign cohort)','FontSize',26);
ylabel('r_{est}, estimated mislabeling rate','FontSize',26);
title('Robustness of mislabeling rate inference','FontSize',26);


[ Am,Az_m,Aci_m,Aciz_m ] = AUC_Sensitivity_To_Mislabeling(r_test,X,Y,Z,P_model(1:N_X),GLM_function )
figure;plot(r_test,Am,'LineWidth',2);hold on;fill([r_test r_test(length(r_test):-1:1)],[Aci_m(1,:) Aci_m(2,length(r_test):-1:1)],'b','LineWidth',2);
hold on;plot(r_test,Az_m,'r','LineWidth',2);hold on;fill([r_test r_test(length(r_test):-1:1)],[Aciz_m(1,:) Aciz_m(2,length(r_test):-1:1)],'r','LineWidth',2);
set(gca,'FontSize',24,'LineWidth',2);
xlabel('r, mislabeling rate in the benign cohort','FontSize',26);
ylabel('AUC(r)','FontSize',26);

